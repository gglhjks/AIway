import AILandingPage from './components/AILandingPage';

function App() {
  return <AILandingPage />;
}

export default App;
